export const database='mongodb+srv://HealthEase:VITians@health-ease.vkrd6.mongodb.net/User?retryWrites=true&w=majority&appName=Health-Ease';
export const jwtSecret = '48u1545uA';